
package Myproject;

public class Course {
    private  final String course_name;
    private int course_code;
    private String program_name;
    private int course_offered;

    public Course(String course_name, int course_code,int course_offered) {
        this.course_name = course_name;
        this.course_code = course_code;
        this.course_offered = course_offered;
        
        
    }
    
    public String getCourse_name() {
        return course_name;
    }

    public int getCourse_code() {
        return course_code;
    }

    public void setCourse_code(int course_code) {
        this.course_code = course_code;
    }

    @Override
    public String toString(){
        return String.format("course name = %s course code = %d course offered = %d " ,course_name,course_code,course_offered);
    }
    
    
    
}
